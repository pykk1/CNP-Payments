1. Nu am gasit informatii in legatura cu secolul in care s-au nascut persoanele carora le incepe CNP-ul 
cu 7, 8 si 9 si le-am considerat a fi nascute dupa anul 2000.

2. Nu am gasit informatii in legatura cu campul "foreigner" din interfata "CnpParts" pentru persoanele carora
le incepe CNP-ul cu 7 si 8(rezidentii) si i-am considerat romani(foreigner = false).