package ro.axonsoft.internship21.cnp;

public interface CalDate {
    Short year();
    Byte month();
    Byte day();

    void setYear(Short year);
    void setMonth(Byte month);
    void setDay(Byte day);
}
