package ro.axonsoft.internship21.pay;

public class IOException extends Exception{
    public IOException() {
        super("IOException");
    }
}
