package ro.axonsoft.internship21.cnp;

public class CnpException extends Exception {
    public CnpException(String message){
        super(message);
    }
}
