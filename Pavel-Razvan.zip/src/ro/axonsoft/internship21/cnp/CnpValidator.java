package ro.axonsoft.internship21.cnp;

public interface CnpValidator {
    CnpParts validateCnp(String cnp) throws CnpException;
}
