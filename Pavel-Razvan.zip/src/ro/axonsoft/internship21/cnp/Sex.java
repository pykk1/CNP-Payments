package ro.axonsoft.internship21.cnp;

public enum Sex {
    M,
    F,
    U
}
