package ro.axonsoft.internship21.cnp;

public enum Judet {
    AB,AR,AG,BC,BH,BN,BT,BV,BR,BZ,
    CS,CJ,CO,CV,DB,DJ,GL,GJ,HG,HD,
    IL,IS,IF,MM,MH,MS,NT,OT,PH,SM,
    SJ,SB,SV,TR,TM,TL,VS,VL,VN,BU,
    CL,GR
}
